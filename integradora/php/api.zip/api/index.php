<?php
require 'flight/Flight.php';
require 'flight/core/Database.php';  
require 'flight/core/Cliente.php';  

Flight::route('GET /clientes', function(){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $result = $cliente->read();

    $clientes_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $cliente_item = array(
            'ID_cliente' => $ID_cliente,
            'Nombres' => $Nombres,
            'Apellido_P' => $Apellido_P,
            'Apellido_M' => $Apellido_M,
            'Telefono' => $Telefono,
            'correo' => $correo
        );
        array_push($clientes_arr, $cliente_item);
    }

    Flight::json($clientes_arr);
});

Flight::start();
?>
