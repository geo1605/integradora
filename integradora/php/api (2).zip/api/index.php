<?php
require 'flight/Flight.php';
require 'flight/core/Database.php';  
require 'flight/core/Cliente.php';  
require 'flight/core/Producto.php';

Flight::route('GET /clientes', function(){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $result = $cliente->read();

    $clientes_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $cliente_item = array(
            'ID_cliente' => $ID_cliente,
            'Nombres' => $Nombres,
            'Apellido_P' => $Apellido_P,
            'Apellido_M' => $Apellido_M,
            'Telefono' => $Telefono,
            'correo' => $correo
        );
        array_push($clientes_arr, $cliente_item);
    }
    if (count($clientes_arr) > 0) {
        Flight::json($clientes_arr);
    } else {
        Flight::json(array('message' => 'No se encontraron clientes.'));
    }

    Flight::json($clientes_arr);
});
Flight::route('POST /clientes', function(){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $data = json_decode(Flight::request()->getBody());

    $cliente->Nombres = $data->Nombres;
    $cliente->Apellido_P = $data->Apellido_P;
    $cliente->Apellido_M = $data->Apellido_M;
    $cliente->Telefono = $data->Telefono;
    $cliente->correo = $data->correo;

    if ($cliente->create()) {
        Flight::json(array('message' => 'Cliente creado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser creado.'), 500);
    }
});
Flight::route('PUT /clientes/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $data = json_decode(Flight::request()->getBody());

    $cliente->ID_cliente = $id;
    $cliente->Nombres = $data->Nombres;
    $cliente->Apellido_P = $data->Apellido_P;
    $cliente->Apellido_M = $data->Apellido_M;
    $cliente->Telefono = $data->Telefono;
    $cliente->correo = $data->correo;

    if ($cliente->update()) {
        Flight::json(array('message' => 'Cliente actualizado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser actualizado.'), 500);
    }
});
Flight::route('DELETE /clientes/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $cliente->ID_cliente = $id;

    if ($cliente->delete()) {
        Flight::json(array('message' => 'Cliente eliminado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser eliminado.'), 500);
    }
});

Flight::start();
?>
