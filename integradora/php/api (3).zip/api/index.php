<?php
require 'flight/Flight.php';
require 'flight/core/Database.php';  
require 'flight/core/Cliente.php';  
require 'flight/core/Producto.php';
require 'flight/core/Direccion.php';
require 'flight/core/Zona.php';

//CLIENTES//

Flight::route('GET /clientes', function(){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $result = $cliente->read();

    $clientes_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $cliente_item = array(
            'ID_cliente' => $ID_cliente,
            'Nombres' => $Nombres,
            'Apellido_P' => $Apellido_P,
            'Apellido_M' => $Apellido_M,
            'Telefono' => $Telefono,
            'correo' => $correo
        );
        array_push($clientes_arr, $cliente_item);
    }
    if (count($clientes_arr) > 0) {
        Flight::json($clientes_arr);
    } else {
        Flight::json(array('message' => 'No se encontraron clientes.'));
    }

    Flight::json($clientes_arr);
});
Flight::route('POST /clientes', function(){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $data = json_decode(Flight::request()->getBody());

    $cliente->Nombres = $data->Nombres;
    $cliente->Apellido_P = $data->Apellido_P;
    $cliente->Apellido_M = $data->Apellido_M;
    $cliente->Telefono = $data->Telefono;
    $cliente->correo = $data->correo;

    if ($cliente->create()) {
        Flight::json(array('message' => 'Cliente creado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser creado.'), 500);
    }
});
Flight::route('PUT /clientes/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $data = json_decode(Flight::request()->getBody());

    $cliente->ID_cliente = $id;
    $cliente->Nombres = $data->Nombres;
    $cliente->Apellido_P = $data->Apellido_P;
    $cliente->Apellido_M = $data->Apellido_M;
    $cliente->Telefono = $data->Telefono;
    $cliente->correo = $data->correo;

    if ($cliente->update()) {
        Flight::json(array('message' => 'Cliente actualizado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser actualizado.'), 500);
    }
});
Flight::route('DELETE /clientes/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $cliente = new Cliente($db);
    $cliente->ID_cliente = $id;

    if ($cliente->delete()) {
        Flight::json(array('message' => 'Cliente eliminado.'));
    } else {
        Flight::json(array('message' => 'Cliente no pudo ser eliminado.'), 500);
    }
});

//PRODUCTOS

Flight::route('GET /productos', function(){
    $database = new Database();
    $db = $database->connect();

    $producto = new Producto($db);
    $result = $producto->read();

    $productos_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $producto_item = array(
            'ID_product' => $ID_product,
            'Nombre' => $Nombre,
            'tipo' => $tipo,
            'Categoria' => $Categoria,
            'precio' => $precio,
            'estatus' => $estatus
        );
        array_push($productos_arr, $producto_item);
    }
    if (count($productos_arr) > 0) {
        Flight::json($productos_arr);
    } else {
        Flight::json(array('message' => 'No se encontraron productos.'));
    }

    Flight::json($productos_arr);
});
Flight::route('POST /productos', function(){
    $database = new Database();
    $db = $database->connect();

    $producto = new Producto($db);
    $data = json_decode(Flight::request()->getBody());

    $producto->Nombre = $data->Nombre;
    $producto->tipo = $data->tipo;
    $producto->Categoria = $data->Categoria;
    $producto->precio = $data->precio;
    $producto->estatus = $data->estatus;

    if ($producto->create()) {
        Flight::json(array('message' => 'Producto creado.'));
    } else {
        Flight::json(array('message' => 'Producto no pudo ser creado.'), 500);
    }
});
Flight::route('PUT /productos/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $producto = new Producto($db);
    $data = json_decode(Flight::request()->getBody());

    $producto->ID_product = $id;
    $producto->Nombre = $data->Nombre;
    $producto->tipo = $data->tipo;
    $producto->Categoria = $data->Categoria;
    $producto->precio = $data->precio;
    $producto->estatus = $data->estatus;

    if ($producto->update()) {
        Flight::json(array('message' => 'Producto actualizado.'));
    } else {
        Flight::json(array('message' => 'Producto no pudo ser actualizado.'), 500);
    }
});
Flight::route('DELETE /productos/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $producto = new Producto($db);
    $producto->ID_product = $id;

    if ($producto->delete()) {
        Flight::json(array('message' => 'Producto eliminado.'));
    } else {
        Flight::json(array('message' => 'Producto no pudo ser eliminado.'), 500);
    }
});

//DIRECCION//

Flight::route('GET /direcciones', function(){
    $database = new Database();
    $db = $database->connect();

    $direccion = new Direccion($db);
    $result = $direccion->read();

    $direccion_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $direccion_item = array(
            'id_direccion' => $id_direccion,
            'calle' => $calle,
            'numero' => $numero,
            'colonia' => $colonia,
            'id_zona' => $id_zona,
            'ID_cliente' => $ID_cliente
        );
        array_push($direccion_arr, $direccion_item);
    }
    if (count($direccion_arr) > 0) {
        Flight::json($direccion_arr);
    } else {
        Flight::json(array('message' => 'No se encontraron direcciones.'));
    }

    Flight::json($direccion_arr);
});
Flight::route('POST /direcciones', function(){
    $database = new Database();
    $db = $database->connect();

    $direccion = new Direccion($db);
    $data = json_decode(Flight::request()->getBody());

    $direccion->calle = $data->calle;
    $direccion->numero = $data->numero;
    $direccion->colonia = $data->colonia;
    $direccion->id_zona = $data->id_zona;
    $direccion->ID_cliente = $data->ID_cliente;

    if ($direccion->create()) {
        Flight::json(array('message' => 'Direccion creado.'));
    } else {
        Flight::json(array('message' => 'Direccion no pudo ser creado.'), 500);
    }
});
Flight::route('PUT /direcciones/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $direccion = new Direccion($db);
    $data = json_decode(Flight::request()->getBody());

    $direccion->id_direccion = $id;
    $direccion->calle = $data->calle;
    $direccion->numero = $data->numero;
    $direccion->colonia = $data->colonia;
    $direccion->id_zona = $data->id_zona;
    $direccion->ID_cliente = $data->ID_cliente;

    if ($direccion->update()) {
        Flight::json(array('message' => 'Direccion actualizado.'));
    } else {
        Flight::json(array('message' => 'Direccion no pudo ser actualizado.'), 500);
    }
});
Flight::route('DELETE /direcciones/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $direccion = new Direccion($db);
    $direccion->id_direccion = $id;

    if ($direccion->delete()) {
        Flight::json(array('message' => 'Direccion eliminado.'));
    } else {
        Flight::json(array('message' => 'Direccion no pudo ser eliminado.'), 500);
    }
});

//ZONA//

Flight::route('GET /zonas', function(){
    $database = new Database();
    $db = $database->connect();

    $zona = new Zona($db);
    $result = $zona->read();

    $zona_arr = array();
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $zona_item = array(
            'ID_zona' => $ID_zona,
            'nombre_colonia' => $nombre_colonia,
            'costo_zona' => $costo_zona
        );
        array_push($zona_arr, $zona_item);
    }
    if (count($zona_arr) > 0) {
        Flight::json($zona_arr);
    } else {
        Flight::json(array('message' => 'No se encontraron zonas.'));
    }

    Flight::json($zona_arr);
});
Flight::route('POST /zonas', function(){
    $database = new Database();
    $db = $database->connect();

    $zona = new Zona($db);
    $data = json_decode(Flight::request()->getBody());

    $zona->nombre_colonia = $data->nombre_colonia;
    $zona->costo_zona = $data->costo_zona;

    if ($zona->create()) {
        Flight::json(array('message' => 'Zona creado.'));
    } else {
        Flight::json(array('message' => 'Zona no pudo ser creado.'), 500);
    }
});
Flight::route('PUT /zonas/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $zona = new Zona($db);
    $data = json_decode(Flight::request()->getBody());

    $zona->ID_zona = $id;
    $zona->nombre_colonia = $data->nombre_colonia;
    $zona->costo_zona = $data->costo_zona;

    if ($zona->update()) {
        Flight::json(array('message' => 'Zona actualizado.'));
    } else {
        Flight::json(array('message' => 'Zona no pudo ser actualizado.'), 500);
    }
});
Flight::route('DELETE /zonas/@id', function($id){
    $database = new Database();
    $db = $database->connect();

    $zona = new Zona($db);
    $zona->ID_zona = $id;

    if ($zona->delete()) {
        Flight::json(array('message' => 'Zona eliminado.'));
    } else {
        Flight::json(array('message' => 'Zona no pudo ser eliminado.'), 500);
    }
});

Flight::start();
?>
